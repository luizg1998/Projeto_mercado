--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.1
-- Dumped by pg_dump version 14.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE mercado;
--
-- Name: mercado; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE mercado WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE mercado OWNER TO postgres;

\connect mercado

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: detalhes_venda; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detalhes_venda (
    id integer NOT NULL,
    id_venda integer NOT NULL,
    id_produto integer NOT NULL,
    qtd_produto integer,
    total_valor_produto real,
    total_valor_imposto real
);


ALTER TABLE public.detalhes_venda OWNER TO postgres;

--
-- Name: detalhes_venda_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.detalhes_venda ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.detalhes_venda_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: produtos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produtos (
    id integer NOT NULL,
    nome character varying(100) NOT NULL,
    valor real NOT NULL,
    id_tipo_produto integer NOT NULL
);


ALTER TABLE public.produtos OWNER TO postgres;

--
-- Name: produtos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.produtos ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.produtos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tipos_produtos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tipos_produtos (
    id integer NOT NULL,
    nome_tipo character varying(100) NOT NULL,
    perc_imposto real
);


ALTER TABLE public.tipos_produtos OWNER TO postgres;

--
-- Name: tipos_produtos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tipos_produtos ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tipos_produtos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: venda; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.venda (
    id integer NOT NULL,
    data_venda date DEFAULT now() NOT NULL,
    valor_produtos real,
    valor_impostos real
);


ALTER TABLE public.venda OWNER TO postgres;

--
-- Name: venda_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.venda ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.venda_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: detalhes_venda; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.detalhes_venda (id, id_venda, id_produto, qtd_produto, total_valor_produto, total_valor_imposto) FROM stdin;
\.
COPY public.detalhes_venda (id, id_venda, id_produto, qtd_produto, total_valor_produto, total_valor_imposto) FROM '$$PATH$$/3330.dat';

--
-- Data for Name: produtos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.produtos (id, nome, valor, id_tipo_produto) FROM stdin;
\.
COPY public.produtos (id, nome, valor, id_tipo_produto) FROM '$$PATH$$/3332.dat';

--
-- Data for Name: tipos_produtos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tipos_produtos (id, nome_tipo, perc_imposto) FROM stdin;
\.
COPY public.tipos_produtos (id, nome_tipo, perc_imposto) FROM '$$PATH$$/3334.dat';

--
-- Data for Name: venda; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.venda (id, data_venda, valor_produtos, valor_impostos) FROM stdin;
\.
COPY public.venda (id, data_venda, valor_produtos, valor_impostos) FROM '$$PATH$$/3336.dat';

--
-- Name: detalhes_venda_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.detalhes_venda_id_seq', 8, true);


--
-- Name: produtos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produtos_id_seq', 13, true);


--
-- Name: tipos_produtos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tipos_produtos_id_seq', 31, true);


--
-- Name: venda_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.venda_id_seq', 10, true);


--
-- Name: detalhes_venda detalhes_venda_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalhes_venda
    ADD CONSTRAINT detalhes_venda_pkey PRIMARY KEY (id);


--
-- Name: produtos produtos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produtos
    ADD CONSTRAINT produtos_pkey PRIMARY KEY (id);


--
-- Name: tipos_produtos tipos_produtos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tipos_produtos
    ADD CONSTRAINT tipos_produtos_pkey PRIMARY KEY (id);


--
-- Name: venda venda_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.venda
    ADD CONSTRAINT venda_pkey PRIMARY KEY (id);


--
-- Name: detalhes_venda fk_id_produto; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalhes_venda
    ADD CONSTRAINT fk_id_produto FOREIGN KEY (id_produto) REFERENCES public.produtos(id);


--
-- Name: detalhes_venda fk_id_venda; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalhes_venda
    ADD CONSTRAINT fk_id_venda FOREIGN KEY (id_venda) REFERENCES public.venda(id) ON DELETE CASCADE;


--
-- Name: produtos fk_idtipoproduto; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produtos
    ADD CONSTRAINT fk_idtipoproduto FOREIGN KEY (id_tipo_produto) REFERENCES public.tipos_produtos(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

